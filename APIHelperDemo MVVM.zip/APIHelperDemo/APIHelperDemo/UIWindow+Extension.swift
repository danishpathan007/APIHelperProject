//
//  UIWindow+Extension.swift
//  APIHelperDemo
//
//  Created by WC IOS 01 on 02/06/22.
//

import Foundation
import UIKit
import NVActivityIndicatorView

extension UIWindow {
    
    private static let association = ObjectAssociation<UIView>()
    
    var activityIndicator: UIView {
        set { UIWindow.association[self] = newValue }
        get {
            if let indicator = UIWindow.association[self] {
                return indicator
            } else {
                UIWindow.association[self] = NVActivityIndicatorView.customIndicator(view: self)
                return UIWindow.association[self]!
            }
        }
    }
    
    // MARK: - Activity Indicator
    public func startIndicatingActivity() {
        DispatchQueue.main.async {
            self.addSubview(self.activityIndicator)
            UIApplication.shared.beginIgnoringInteractionEvents()
        }
    }
    
    public func stopIndicatingActivity() {
        DispatchQueue.main.async {
            self.activityIndicator.removeFromSuperview()
            UIApplication.shared.endIgnoringInteractionEvents()
        }
    }
    
}


