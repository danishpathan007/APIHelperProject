//
//  LoginViewModel.swift
//  APIHelperDemo
//
//  Created by WC IOS 01 on 02/06/22.
//

import Foundation

class LoginViewModel : NSObject {
    
    private var apiService : APIManager!
    private(set) var loginModel : LoginModel! {
        didSet {
            self.bindLoginViewModelToController()
        }
    }
    
    var bindLoginViewModelToController : (() -> ()) = {}
    
    override init() {
        super.init()
        self.apiService =  APIManager.shared()
    }
    
    func login() {
        getProfile { loginModel, error in
            if let loginModel = loginModel {
                self.loginModel = loginModel
            }
        }
    }
    
    
    func getProfile(handler: @escaping ( _ loginModel: LoginModel?, _ error: AlertMessage?)->()) {
        
        let parm = ["countryId": 2,
                    "email": "",
                     "phoneNumber": "9690739077",
                     "password": "123456",
                     "deviceType": "iOS",
                     "deviceAddress": "E96CEA5B-8E59-4E35-9519-AB2F1CBF2B5C",
                     "fcmToken": "cXmbmFFxo0KZudsd5G72tP:APA91bFQt47XfFYIqOFg5ZugMVP1jyRNGV1hBuGUVDF95nbDq1L7ghVIKkGQRhcgKmDQJywKB96VEgMib8LAWtQTaC6CRWmANt0j4_w5RSfM5ip8sajDzGSP8KuZICOxs8mgpFh0Yilq",
                     "loginType": "phone",
                     "roleId" : 2,
                     "fbLinked": false,
                     "googleLinked": false,
                     "appleLinked": false,
                     "fbLinkedId": "",
                     "googleLinkedId": "",
                     "appleLinkedId": ""
        ] as [String : Any]
        
        apiService.call(type: EndpointItem.login,params: parm) { (loginModel: LoginModel?, message: AlertMessage?) in
            if let loginModel = loginModel {
                if loginModel.success ?? false {
                    print(loginModel.data?.token)
                    handler(loginModel, nil)
                }else{
                    print("Error \(loginModel.message)")
                    handler(nil, message!)
                }
            } else {
                handler(nil, message!)
            }
        }
    }
    
    func updateProfile(handler: @escaping ( _ loginModel: LoginModel?, _ error: AlertMessage?)->()) {

        let parm = [ "LocationName": "Sector 82, Mohali", "Experience": "6", "FirstName": "Albertss", "LastName": "William", "Bio": "Wedding planner", "userId": "0", "CreatedBy": "0", "Latitude": "30.650385"]

        //let imageData = #imageLiteral(resourceName: "user").jpegData(compressionQuality: 0.75)

        apiService.upload(type: EndpointItem.saveUpdatePlannerProfile, params: parm, imageData: nil) { (loginModel: LoginModel?, message: AlertMessage?) in
            if let loginModel = loginModel {
                if loginModel.success ?? false {
                    print(loginModel.data?.token)
                }else{
                    print("Error \(loginModel.message)")
                }
                handler(nil, nil)
            } else {
                handler(loginModel, message!)
            }
        }
    }

    
}
