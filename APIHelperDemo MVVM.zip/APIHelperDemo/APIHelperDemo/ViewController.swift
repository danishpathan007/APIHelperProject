//
//  ViewController.swift
//  APIHelperDemo
//
//  Created by WC IOS 01 on 01/06/22.
//

import UIKit
import Alamofire

class ViewController: UIViewController {

  
    let loginViewModel = LoginViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.startIndicatingActivity()
        
        loginViewModel.login()
        
        loginViewModel.bindLoginViewModelToController = {
            self.stopIndicatingActivity()
            self.view.backgroundColor = .blue
        }
                        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)

    }


}




// MARK: - Welcome
struct LoginModel: Codable {
    let success: Bool?
    let status: Int?
    let data: DataClass?
    let offset, message: String?
}

// MARK: - DataClass
struct DataClass: Codable {
    let token: String?
    let userInfo: UserInfo?
}

// MARK: - UserInfo
struct UserInfo: Codable {
    let isSuspended: Bool?
    let lastName, locationName: String?
    let otp: String?
    let bio: String?
    let userImage: String?
    let countryCode: String?
    let latitude: Double?
    let groomName, phoneNumber: String?
    let userID: Int?
    let isBioSaved, hasActiveSubscription: Bool?
    let budgetTo: Int?
    let qrCodeImage: String?
    let noOfGuest, budgetFrom, countryID: Int?
    let brideName, experience: String?
    let longitude: Double?
    let isShowNotifications: Bool?
    let countryName, stripeAccountID, firstName, emailID: String?
    let isSocialLogin: Bool?
    let roleID: Int?

    enum CodingKeys: String, CodingKey {
        case isSuspended, lastName, locationName, otp, bio, userImage, countryCode, latitude, groomName, phoneNumber
        case userID
        case isBioSaved, hasActiveSubscription, budgetTo, qrCodeImage, noOfGuest, budgetFrom
        case countryID
        case brideName, experience, longitude, isShowNotifications, countryName
        case stripeAccountID
        case firstName
        case emailID
        case isSocialLogin
        case roleID
    }
}

// MARK: - Encode/decode helpers

class JSONNull: Codable, Hashable {

    public static func == (lhs: JSONNull, rhs: JSONNull) -> Bool {
        return true
    }

    public var hashValue: Int {
        return 0
    }

    public init() {}

    public required init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if !container.decodeNil() {
            throw DecodingError.typeMismatch(JSONNull.self, DecodingError.Context(codingPath: decoder.codingPath, debugDescription: "Wrong type for JSONNull"))
        }
    }

    public func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        try container.encodeNil()
    }
}
