//
//  UIViewController+Extension.swift
//  APIHelperDemo
//
//  Created by WC IOS 01 on 02/06/22.
//

import Foundation
import UIKit
import NVActivityIndicatorView

extension UIViewController {
    private static let association = ObjectAssociation<UIView>()
    
    var activityIndicator: UIView {
        set { UIViewController.association[self] = newValue }
        get {
            if let indicator = UIViewController.association[self] {
                return indicator
            } else {
                UIViewController.association[self] = NVActivityIndicatorView.customIndicator(view: self.view)
                return UIViewController.association[self]!
            }
        }
    }
    
    // MARK: - Acitivity Indicator
    public func startIndicatingActivity() {
        DispatchQueue.main.async {
            self.view.addSubview(self.activityIndicator)
        }
    }
    
    public func stopIndicatingActivity() {
        DispatchQueue.main.async {
            self.activityIndicator.removeFromSuperview()
        }
    }
}



extension NVActivityIndicatorView{
    public static func customIndicator(view:UIView) -> UIView {
       let bgView = UIView()
       bgView.frame = view.frame
       bgView.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.4)
       print(view.frame.width/2)
        let activityIndicator = NVActivityIndicatorView(frame: CGRect(x: view.center.x - 20, y: view.frame.height/2 - 20, width: 50, height: 50), type: .ballSpinFadeLoader, color:  UIColor.red, padding: NVActivityIndicatorView.DEFAULT_PADDING)
       print(view.frame)
       view.addSubview(bgView)
       bgView.addSubview(activityIndicator)
       activityIndicator.startAnimating()
       return bgView
   }
}


public final class ObjectAssociation<T: AnyObject> {
    
    private let policy: objc_AssociationPolicy
    
    /// - Parameter policy: An association policy that will be used when linking objects.
    public init(policy: objc_AssociationPolicy = .OBJC_ASSOCIATION_RETAIN_NONATOMIC) {
        
        self.policy = policy
    }
    
    /// Accesses associated object.
    /// - Parameter index: An object whose associated object is to be accessed.
    public subscript(index: AnyObject) -> T? {
        
        get { return objc_getAssociatedObject(index, Unmanaged.passUnretained(self).toOpaque()) as! T? }
        set { objc_setAssociatedObject(index, Unmanaged.passUnretained(self).toOpaque(), newValue, policy) }
    }
}
