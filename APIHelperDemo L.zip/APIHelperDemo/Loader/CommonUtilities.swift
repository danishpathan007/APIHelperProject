//
//  CommonUtilities.swift
//  APIHelperDemo
//
//  Created by WC IOS 01 on 02/06/22.
//

import Foundation
import UIKit

class CommonUtilities {
    class Loader{
        class func showProgressBar(_ msg:String = "Loading...", shouldEndEditing:Bool){
            var loaderConfiguration = SwiftLoader.Config()
            loaderConfiguration.size = 100
            loaderConfiguration.backgroundColor = UIColor.systemGray5
            loaderConfiguration.spinnerColor = UIColor.black
            loaderConfiguration.titleTextColor = UIColor.black
            loaderConfiguration.spinnerLineWidth = 1.0
            loaderConfiguration.foregroundColor = UIColor.blue
            loaderConfiguration.foregroundAlpha = 0.5
            SwiftLoader.setConfig(config: loaderConfiguration)
            SwiftLoader.show(title: msg, animated: true, shouldEndEditing:shouldEndEditing)
        }
        
        class func hideProgressBar() {
            SwiftLoader.hide()
        }
    }
}
