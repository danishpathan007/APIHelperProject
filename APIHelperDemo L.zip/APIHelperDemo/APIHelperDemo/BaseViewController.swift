//
//  BaseViewController.swift
//  APIHelperDemo
//
//  Created by WC IOS 01 on 02/06/22.
//

import UIKit

class BaseViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
}
